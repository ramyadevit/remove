﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlsDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] skills = new string[4];

            if (checkBox1.Checked)
            {
                skills[0] = checkBox1.Text;
            }
            else if (checkBox2.Checked)
            {
                skills[1] = checkBox2.Text;
            }
            else if (checkBox3.Checked)
            {
                skills[2] = checkBox3.Text;
            }
            else if (checkBox4.Checked)
            {
                skills[3] = checkBox4.Text;
            }

            string[] appliedPosition;

            foreach(object item in listBox1.Items)
            {
                //appliedPosition.Join(item.ToString());
            }

            string Degree = checkedListBox1.Text;

            int PassedOut = Convert.ToInt32(comboBox1.Text);

           string datetimeVal = dateTimePicker1.Value.ToString();

           string phone = maskedTextBox1.Text;

            MessageBox.Show(Degree + PassedOut + phone);
            //Store into DB
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("2016");
            comboBox1.Items.Add("2017");
            comboBox1.Items.Add("2018");
            comboBox1.Items.Add("2019");
            comboBox1.Items.Add("2020");
            comboBox1.Items.Add("2021");

            checkedListBox1.Items.Add("+12");
            checkedListBox1.Items.Add("BE");
            checkedListBox1.Items.Add("ME");
            checkedListBox1.Items.Add("MCA");

            listBox1.Items.Add("Developer");
            listBox1.Items.Add("Tester");
            listBox1.Items.Add("DB Admin");
            listBox1.Items.Add("Front Office");
        }
    }
}
