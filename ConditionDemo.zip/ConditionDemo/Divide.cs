﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConditionDemo
{
    public partial class Divide : Form
    {
        public Divide()
        {
            InitializeComponent();
        }

        private void Divide_Load(object sender, EventArgs e)
        {
            checkedListBox1.Items.Add("C#");
            checkedListBox1.Items.Add("Java");
            checkedListBox1.Items.Add("Azure");
            checkedListBox1.Items.Add("Python");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var res = checkedListBox1.SelectedItems;
        }
    }
}
