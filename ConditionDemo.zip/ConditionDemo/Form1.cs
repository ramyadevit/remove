﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConditionDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //int num1 = 100;

            Int32 number1 = Convert.ToInt32(textBox1.Text);

            Int32 number2 = Convert.ToInt32(textBox2.Text);

            //if condition
            //int number1 = 55;
            //int number2 = 65;

            //if (number1 == number2)
            //{
            //    MessageBox.Show("Numbers Are Equal!!");
            //}
            //else
            //{
            //    MessageBox.Show("Numbers Are Not Equal");
            //}

            //if (number1 != number2)  //True
            //{
            //    MessageBox.Show("Numbers Are Not Equal!!");
            //}
            //else //False
            //{
            //    MessageBox.Show("Numbers Are Equal");
            //}

            if (number1 >= number2)  //True
            {
                MessageBox.Show("Numbers Are Not Equal!!");
            }
            else //False
            {
                MessageBox.Show("Numbers Are Equal");
            }


            //Logical Operators
            if (number1 > 0 && number1 >= number2)  //True
            {
                MessageBox.Show("Numbers Are Not Equal!!");
            }
            else //False
            {
                MessageBox.Show("Numbers Are Equal");
            }

            //Logical Operators
            //if (time > 8 && time < 12)  //True
            //{
            //    MessageBox.Show("Good Morning!!");
            //}
            //else //False
            //{
            //    MessageBox.Show("Numbers Are Equal");
            //}

            int currentHour = DateTime.Now.Hour;

            if (currentHour > 8 && currentHour < 12)
            {
                MessageBox.Show("Good Morning");
            }
            else if (currentHour > 12 && currentHour < 16)
            {
                MessageBox.Show("Good Afternoon");
            }
            else if (currentHour > 16 && currentHour < 19)
            {
                MessageBox.Show("Good Evening");
            }
            else if (currentHour > 19 && currentHour < 22)
            {
                MessageBox.Show("Good Night");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //int x = 10;

            //int y = 20;

            //int z = 90;

            //int a = 30;

            //int b = 40;

            ////0  - (n -1) 2
            //int num = 10;

            //First
            int[] oldNum = new int[5];
            oldNum[0] = 10;
            oldNum[1] = 20;
            oldNum[2] = 30;
            oldNum[3] = 40;
            oldNum[4] = 50;

            //inter
            int[] middleArr = new int[] { 10, 20, 30 };

            //latest
            int[] numbers = { 10, 20, 30 };

            string[] cities = { "chennai", "Mumbai" };

            double[] marks = { 55.23, 55.56, 55.89 };
            int count2 = 0;
            if (count2 < 3)
            {

            }
            //Part1 variable dec
            //paart 2 - condition check
            //Part 3 - Incremental
            for (int count = 0; count < 2; count++)
            {
                MessageBox.Show(Convert.ToString(numbers[count]));
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string name = textBox4.Text;

            string userpass = textBox3.Text;

            if (name == "karthik" && userpass == "Admin")
            {
                MessageBox.Show("Good Night");
            }
        }
    }
}
