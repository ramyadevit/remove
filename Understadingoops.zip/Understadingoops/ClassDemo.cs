﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Understadingoops
{
    public partial class ClassDemo : Form
    {
        public ClassDemo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Class - Object
            Employee obj = new Employee();

            obj.empNo = Convert.ToInt32(textBox1.Text);

            obj.emplName = textBox2.Text;

            obj.empPhone = Convert.ToInt64(maskedTextBox1.Text);
            obj.empMail = maskedTextBox2.Text;

            obj.empAddress[0] = textBox5.Text;
            obj.empSalary = Convert.ToDecimal(textBox6.Text);



            Mobile mobile = new Mobile();
            mobile.brand = "Samsung";
            mobile.Model = "M55";
            mobile.ramCapacity = "4 GB";

            Mobile appleObj = new Mobile();
            appleObj.brand = "Apple";
            appleObj.Model = "13";
            appleObj.ramCapacity = "8 GB";

        }

        private void ClassDemo_Load(object sender, EventArgs e)
        {

        }
    }

    public class Employee
    {
        public int empNo;

        public string emplName;

        public long empPhone;

        public string empMail;

        public string[] empAddress;

        public decimal empSalary;
    }

    public class Mobile
    {
        //Constructor


        //Fields
        public long imeiNumber;

        public string brand;

        //public string Model;

        public string ramCapacity;

        private int modelTest;

        //Property
        public string Model { get; set; }

        //public int ModelTest
        //{
        //    get { return modelTest; }
        //    set
        //    {
        //        if(modelTest < 2000)
        //        {
        //            throw new Exception("Enter More than 2000");
        //        }
        //        else
        //        {
        //            modelTest = value;
        //        }
        //    }
        //}

        //method
        public Mobile GetMobileDetails(int mobileModel)
        {
            //DB - Opration 

            Mobile mobile = new Mobile();
            return mobile;
        }

        public void AddMobile(Mobile mobile)
        {
            //ADD mobile to DB
        }

        public Mobile[] GetMobiles()
        {
            //ADD mobile to DB
            Mobile[] mobiles = null;
            return mobiles;
        }

        //Event


        //Desctor
    }

}
