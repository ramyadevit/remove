﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EncapDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CustomerAccount customer = new CustomerAccount();

            CalculateInterest calculate = new CalculateInterest();

        }
    }

    public class CustomerAccount
    {
        public string CustomerNumber { get; set; }

        public string AccuntNumber { get; set; }

        protected string CarNumber { get; set; }

        private int CardPin { get; set; }

        public void AddCustomer(CustomerAccount customer)
        {
            string acc = customer.AccuntNumber;
            customer.CardPin = 5454;
        }
    }

    public class CalculateInterest : CustomerAccount
    {

    }


}
