﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EncapDemo
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num1 = Convert.ToInt32(textBox1.Text);
            int num2 = Convert.ToInt32(textBox2.Text);
            int num3 = Convert.ToInt32(textBox3.Text);
            int num4 = Convert.ToInt32(textBox4.Text);

            if (num1 > 0 && num2 > 0)
            {
                AddNumbers(num1, num2);
            }
            else if (num1 > 0 && num2 > 0 && num3 > 0)
            {
                AddNumbers(num1, num2, num3);
            }
            MessageBox.Show("I am fine with Message box");
            MessageBox.Show("This is testing", "MyHeading");
            MessageBox.Show("This is testing", "MyHeading",MessageBoxButtons.YesNoCancel);
        }


        public int AddNumbers(int number, int num2)
        {
            int res = number + num2;
            return res;
        }

        public int AddNumbers(double num1, int num2)
        {
            int res = Convert.ToInt32(num1) + num2;
            return res;
        }


        public int AddNumbers(int num1, int num2, int num3)
        {
            int res = num1 + num2 + num3;
            return res;
        }

        public int AddNumbers(int num1, int num2, int num3, int num4)
        {
            int res = num1 + num2 + num3;
            return res;
        }
    }
}
