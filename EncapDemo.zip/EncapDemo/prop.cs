﻿namespace EncapDemo
{
    internal class prop
    {
    }
}