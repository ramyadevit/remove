﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementDemo
{
    public partial class OfficeStaff : Form
    {
        ClsOfficeAssit officeAssit = new ClsOfficeAssit();
        public OfficeStaff()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            officeAssit.empId = textBox1.Text;
            officeAssit.empName = textBox2.Text;
            officeAssit.Qualification = textBox3.Text;
            officeAssit.Experience = Convert.ToInt32(textBox4.Text);
            officeAssit.Basic = Convert.ToInt32(textBox6.Text);
            officeAssit.PF = Convert.ToInt32(textBox7.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ClsOfficeAssit officeAssit = new ClsOfficeAssit();
            officeAssit.Basic = 6000;
            officeAssit.PF = 400;

            long resSalary = officeAssit.CalculateSalary(officeAssit.Basic, officeAssit.PF);
            textBox9.Text = Convert.ToString(resSalary);
        }
    }
}
