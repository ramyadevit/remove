﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolManagementDemo
{
    public class ClsTeacher : AbsClass
    {
        public int Experience { get; set; }
        public int HandlingClass { get; set; }
        public int Allowance { get; set; }

        public override long CalculateSalary(int basicPay, int pfAmt)
        {
            return basicPay + Allowance - pfAmt;
        }
    }
}
