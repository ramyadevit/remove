﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolManagementDemo
{
    public abstract class AbsClass
    {
        public string empId { get; set; }
        public string empName { get; set; }
        public string Qualification { get; set; }
        public int Basic { get; set; }
        public int PF { get; set; }

        public abstract long CalculateSalary(int basicPay, int pfAmt);

    }
}
