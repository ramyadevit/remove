﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolManagementDemo
{
    class ClsOfficeAssit : AbsClass
    {
        public int Experience { get; set; }

        public override long CalculateSalary(int basicPay, int pfAmt)
        {
            return basicPay - pfAmt;
        }
    }
}
