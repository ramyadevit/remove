﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SchoolManagementDemo
{
    public partial class TeachingStaff : Form
    {
        ClsTeacher teacher = new ClsTeacher();
        public TeachingStaff()
        {
            InitializeComponent();
        }

        private void TeachingStaff_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ClsTeacher teacher = new ClsTeacher();

            teacher.Basic = 8000;
            teacher.PF = 500;
            teacher.Allowance = 1200;

            long resSalary = teacher.CalculateSalary(teacher.Basic, teacher.PF);

            textBox9.Text = Convert.ToString(resSalary);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            teacher.empId = textBox1.Text;
            teacher.empName = textBox2.Text;
            teacher.Qualification = textBox3.Text;
            teacher.Experience = Convert.ToInt32(textBox4.Text);
            teacher.HandlingClass = Convert.ToInt32(textBox5.Text);
            teacher.Basic = Convert.ToInt32(textBox6.Text);
            teacher.PF = Convert.ToInt32(textBox7.Text);
            teacher.Allowance = Convert.ToInt32(textBox8.Text);
        }
    }
}
