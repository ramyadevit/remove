﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InherDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Department dObj = new Department();
            dObj.empName = "Karthik";

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
    }

    //Base Class - Parent
    public class Employee
    {
        public string empName { get; set; }
        public string Gender { get; set; }
        public string[] Skills { get; set; }
        public string Degree { get; set; }
        public DateTime PassedYear { get; set; }
    }

    //Derived Class - Child
    public class Department : Employee
    {
        public int DeaprtId { get; set; }
        public string DepartmentName { get; set; }
    }

    public class Project : Employee
    {
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }
    }

    public class Attendacne : Employee
    {
        public int AttendanceId { get; set; }
        public DateTime AttendanceDate { get; set; }
    }




    public class Employee2
    {
        public string empName { get; set; }
        public string Gender { get; set; }
        public string[] Skills { get; set; }
        public string Degree { get; set; }
        public DateTime PassedYear { get; set; }
    }

    //Derived Class - Child
    public class Department2 : Employee2
    {
        public int DeaprtId { get; set; }
        public string DepartmentName { get; set; }
    }

    public class Project2 : Department2
    {
        public int ProjectId { get; set; }
        public string ProjectName { get; set; }

        int getProject()
        {
            return 100;
        }
    }
    public class Attendacne2 : Project2
    {
        public int AttendanceId { get; set; }
        public DateTime AttendanceDate { get; set; }
    }

    public interface IEmployee
    {
        string empName { get; set; }
        string Gender { get; set; }
        string[] Skills { get; set; }
        string Degree { get; set; }
        DateTime PassedYear { get; set; }


        //Abstraction
        int getProject();

    }

    public interface IEmployee2
    {
        string empName { get; set; }
        string Gender { get; set; }
        string[] Skills { get; set; }
        string Degree { get; set; }
        DateTime PassedYear { get; set; }


        //Abstraction
        int getProject();

    }

    //100%
    public interface IEmployee3
    {
        string empName { get; set; }
        string Gender { get; set; }
        string[] Skills { get; set; }
        string Degree { get; set; }
        DateTime PassedYear { get; set; }


        //Abstraction
        int getProject();

    }


    public class EmployeeDemo : IEmployee,IEmployee2,IEmployee3
    {
        public string empName { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public string Gender { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public string[] Skills { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public string Degree { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public DateTime PassedYear { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public int getProject()
        {
            return 10 + 20;
        }
    }

    public abstract class BaseClass
    {
        string empName { get; set; }
        string Gender { get; set; }
        string[] Skills { get; set; }
        string Degree { get; set; }
        DateTime PassedYear { get; set; }


        //Non - Abstraction
        int getProject()
        {
            return 0;
        }

        //Abstraction
        public abstract int getProject2();

    }

}
